# FX Pro Bot — Android starter

This is the first UI prototype for the requested Forex + Crypto trading app.

Included:
- Dark mobile dashboard
- Forex and crypto sample signals
- BUY/SELL action
- Confidence score
- Entry / Stop Loss / Take Profit
- Bot ON/OFF
- Demo/Paper Trading toggle

Important:
The included signals are sample/demo values, not live market predictions.
No 100% win-rate claim is made. Live execution should only be added through an approved broker/exchange API after testing and risk controls.