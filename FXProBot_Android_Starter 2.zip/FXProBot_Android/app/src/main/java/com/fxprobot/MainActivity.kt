package com.fxprobot

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Signal(val pair:String, val market:String, val action:String, val confidence:Int, val entry:String, val sl:String, val tp:String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FXProBotApp() }
    }
}

@Composable
fun FXProBotApp() {
    val signals = listOf(
        Signal("EUR/USD","Forex","BUY",82,"1.08420","1.08280","1.08700"),
        Signal("GBP/USD","Forex","SELL",76,"1.26345","1.26610","1.25800"),
        Signal("BTC/USDT","Crypto","BUY",91,"66842","67450","65980"),
        Signal("ETH/USDT","Crypto","BUY",87,"3231.17","3181.40","3240.00")
    )
    var active by remember { mutableStateOf(true) }
    var demo by remember { mutableStateOf(true) }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Color(0xFF050B12),
        surface = Color(0xFF0C1622),
        primary = Color(0xFF00E676)
    )) {
        Surface(Modifier.fillMaxSize()) {
            LazyColumn(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text("FX Pro Bot 👑", fontSize=28.sp, fontWeight=FontWeight.Bold)
                    Text("AI-powered Forex + Crypto signals", color=Color.LightGray)
                }
                item {
                    Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                        StatCard("Signals","24")
                        StatCard("Win rate","—")
                        StatCard("Mode",if(demo) "DEMO" else "LIVE")
                    }
                }
                item {
                    Card(shape=RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(16.dp)) {
                            Row(verticalAlignment=Alignment.CenterVertically) {
                                Text("Bot Status", fontWeight=FontWeight.Bold)
                                Spacer(Modifier.weight(1f))
                                Switch(checked=active,onCheckedChange={active=it})
                            }
                            Text(if(active) "ACTIVE • scanning markets" else "STOPPED",
                                color=if(active) Color(0xFF00E676) else Color.Red)
                            Spacer(Modifier.height(8.dp))
                            Row(verticalAlignment=Alignment.CenterVertically) {
                                Text("Paper trading")
                                Spacer(Modifier.weight(1f))
                                Switch(checked=demo,onCheckedChange={demo=it})
                            }
                        }
                    }
                }
                item { Text("Live Signals",fontSize=21.sp,fontWeight=FontWeight.Bold) }
                items(signals) { s -> SignalCard(s) }
                item {
                    Text("Note: this starter uses sample signals. Connect an approved market-data/broker API and validate the strategy before any live trading.",
                        color=Color.Gray, fontSize=12.sp)
                }
            }
        }
    }
}

@Composable
fun StatCard(label:String,value:String) {
    Card(Modifier.weight(1f), shape=RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text(label,color=Color.Gray,fontSize=12.sp)
            Text(value,fontWeight=FontWeight.Bold,fontSize=19.sp)
        }
    }
}

@Composable
fun SignalCard(s:Signal) {
    Card(shape=RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Column {
                    Text(s.pair,fontSize=20.sp,fontWeight=FontWeight.Bold)
                    Text(s.market,color=Color.Gray)
                }
                Spacer(Modifier.weight(1f))
                Text(s.action,fontWeight=FontWeight.Bold,
                    color=if(s.action=="BUY") Color(0xFF00E676) else Color(0xFFFF5252))
            }
            Spacer(Modifier.height(8.dp))
            Text("Confidence: ${s.confidence}%",fontWeight=FontWeight.SemiBold)
            Text("Entry  ${s.entry}")
            Text("SL      ${s.sl}")
            Text("TP      ${s.tp}")
        }
    }
}